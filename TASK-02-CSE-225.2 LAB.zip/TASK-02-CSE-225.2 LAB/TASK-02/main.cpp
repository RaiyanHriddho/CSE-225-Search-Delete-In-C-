//NAME: RAIYAN MASOOD HRIDDHO
//  ID: 1931117042


#include<iostream>

using namespace std;
template < typename T >
  class SortedList {

    private:

    T length;
    T *list;
    int currentPos;
    int capacity;
    public:

      SortedList() {

        length = 0;
        currentPos = -1;
        capacity = 10;
        list = new T[capacity];
      }

    SortedList(int capacity) {

      length = 0;
      currentPos = -1;
      this -> capacity = capacity;
      list = new T[capacity];
    }

    void makeEmpty() {

      length = 0;
    }

    bool isFull() {

      return (length == capacity);
    }

    int lengthIs() {

      return length;
    }

    void resetList() {

      currentPos = -1;
    }

    T getNextItem() {

      currentPos++;
      return list[currentPos];
    }

    void insertItem(T item) {

      int location = 0;
      while (location < length) {

        if (item > list[location]) {

          location++;
        } else {

          break;
        }

      }

      for (int index = length; index > location; index--) {
        list[index] = list[index - 1];
      }

      list[location] = item;
      length++;
    }

    void deleteItem(T item) {

      int location = 0;
      while (item != list[location]) {

        location++;
      }

      for (int index = location + 1; index < length; index++) {
        list[index - 1] = list[index];
      }

      length--;
    }

    bool searchItem(T item) {

      int midPoint, first = 0, last = length - 1;
      while (first <= last) {

        midPoint = (first + last) / 2;
        if (item < list[midPoint]) {

          last = midPoint - 1;
        } else if (item > list[midPoint]) {

          first = midPoint + 1;
        } else {

          return true;
        }

      }

      return false;
    }

    void print(){
        for(int i=0;i<length;++i){
            cout<<list[i]<<" ";
        }
        cout<<"\n";
    }
};

int main() {

    SortedList<double> list(5);

    cout<<"Enter 5 list values: ";

    for(int i=0;i<5;++i){
        double d;
        cin>>d;
        list.insertItem(d);
    }

    cout<<"List: ";
    list.print();

    cout<<"Enter value to search: ";
    double s;
    cin>>s;

    cout<<list.searchItem(s)<<"\n";

    cout<<"Enter value to delete: ";
    cin>>s;
    list.deleteItem(s);

    cout<<"List: ";
    list.print();



}
